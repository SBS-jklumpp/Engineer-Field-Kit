# Engineer Field Kit final-release-2026-02-26-r2

## Release Summary
- Final combined overwrite sync release on commit `4e7f080`.
- Includes app/docs/spec updates and refreshed packaged executable.
- Built executable included as `sbs_dsw.exe`.

## Checksums
- SHA256 `sbs_dsw.exe`: `856B7B23C6C917F35354F9E01227F31F41BE59603012C9D6EB0961E1C7CD4EB4`

## Git References
- Tag: `final-release-2026-02-26-r2`
- Commit: `4e7f080`
- Date: `2026-02-26`
